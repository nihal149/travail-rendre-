package beans;

public class Developer {
    private String name;
    private String day;
    private int numberOfScripts;

    public Developer() {
    }

    public Developer(String name, String day, int numberOfScripts) {
        this.name = name;
        this.day = day;
        this.numberOfScripts = numberOfScripts;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getNumberOfScripts() {
        return numberOfScripts;
    }

    public void setNumberOfScripts(int numberOfScripts) {
        this.numberOfScripts = numberOfScripts;
    }
}