package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.util.Scanner;

public class ExoJDBC {
    private String user = "root"; // Nom d'utilisateur de la base de données
    private String password = ""; // Mot de passe de la base de données
    private String url = "jdbc:mysql://localhost/bd1"; // URL de la base de données

    public void maxScriptsPerDay() {
        try (Connection cn = DriverManager.getConnection(url, user, password);
             Statement st = cn.createStatement()) {

            String maxScriptsQuery = "SELECT Developpeurs, Jour, MAX(NbScripts) AS MaxScripts " +
                                      "FROM DevData GROUP BY Jour";
            ResultSet maxScriptsResult = st.executeQuery(maxScriptsQuery);
            System.out.println("Personne ayant réalisé le nombre maximum de scripts en une journée :");
            while (maxScriptsResult.next()) {
                String developpeur = maxScriptsResult.getString("Developpeurs");
                String jour = maxScriptsResult.getString("Jour");
                int maxScripts = maxScriptsResult.getInt("MaxScripts");
                System.out.println("Développeur: " + developpeur + ", Jour: " + jour + ", Max Scripts: " + maxScripts);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL: " + e.getMessage());
        }
    }

    public void totalScriptsPerDeveloper() {
        try (Connection cn = DriverManager.getConnection(url, user, password);
             Statement st = cn.createStatement()) {

            String totalScriptsQuery = "SELECT Developpeurs, SUM(NbScripts) AS TotalScripts " +
                                       "FROM DevData GROUP BY Developpeurs ORDER BY TotalScripts DESC";
            ResultSet totalScriptsResult = st.executeQuery(totalScriptsQuery);
            System.out.println("\nListe des développeurs triés par le nombre total de scripts :");
            while (totalScriptsResult.next()) {
                String developpeur = totalScriptsResult.getString("Developpeurs");
                int totalScripts = totalScriptsResult.getInt("TotalScripts");
                System.out.println("Développeur: " + developpeur + ", Total Scripts: " + totalScripts);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL: " + e.getMessage());
        }
    }

    public void totalScriptsThisWeek() {
        try (Connection cn = DriverManager.getConnection(url, user, password);
             Statement st = cn.createStatement()) {

            String weeklyTotalQuery = "SELECT SUM(NbScripts) AS TotalScriptsSemaine FROM DevData";
            ResultSet weeklyTotalResult = st.executeQuery(weeklyTotalQuery);
            if (weeklyTotalResult.next()) {
                int totalScriptsSemaine = weeklyTotalResult.getInt("TotalScriptsSemaine");
                System.out.println("\nTotal de scripts réalisés en une semaine : " + totalScriptsSemaine);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL: " + e.getMessage());
        }
    }

    public void totalScriptsByDeveloper(String developerName) {
        try (Connection cn = DriverManager.getConnection(url, user, password);
             Statement st = cn.createStatement()) {

            String developerTotalQuery = "SELECT SUM(NbScripts) AS TotalScripts FROM DevData WHERE Developpeurs = '" + developerName + "'";
            ResultSet developerTotalResult = st.executeQuery(developerTotalQuery);
            if (developerTotalResult.next()) {
                int totalScriptsDeveloper = developerTotalResult.getInt("TotalScripts");
                System.out.println("Total de scripts réalisés par " + developerName + ": " + totalScriptsDeveloper);
            } else {
                System.out.println("Aucun script trouvé pour le développeur : " + developerName);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL: " + e.getMessage());
        }
    }

    //  méthode pour  une requête libre
    public void executeUserDefinedQuery() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez votre requête SQL : ");
        String query = scanner.nextLine();

        try (Connection cn = DriverManager.getConnection(url, user, password);
             Statement st = cn.createStatement()) {

            boolean isResultSet = st.execute(query); // Exécute la requête

            if (isResultSet) { // Si la requête produit un ResultSet
                ResultSet resultSet = st.getResultSet();
                ResultSetMetaData metaData = resultSet.getMetaData();

                // Affichage du nombre de colonnes
                int columnCount = metaData.getColumnCount();
                System.out.println("Nombre de colonnes : " + columnCount);

                // Affichage des noms et types des colonnes
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String columnType = metaData.getColumnTypeName(i);
                    System.out.println("Colonne " + i + ": Nom = " + columnName + ", Type = " + columnType);
                }

                // Affichage des résultats ligne par ligne
                System.out.println("Contenu de la table :");
                while (resultSet.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        System.out.print(resultSet.getString(i) + "\t");
                    }
                    System.out.println();
                }
            } else { // Si la requête n'est pas un SELECT, affiche le nombre de lignes modifiées
                int rowsAffected = st.getUpdateCount();
                System.out.println("Nombre de lignes modifiées : " + rowsAffected);
            }
        } catch (SQLException e) {
            System.out.println("Erreur SQL: " + e.getMessage());
        }
    }
}