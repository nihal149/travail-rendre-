package test;

import beans.ExoJDBC;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        ExoJDBC exoJDBC = new ExoJDBC();
        
        //  les méthodes pour tester les fonctionnalités existantes
        exoJDBC.maxScriptsPerDay();
        exoJDBC.totalScriptsPerDeveloper();
        exoJDBC.totalScriptsThisWeek();

        // le nombre total de scripts réalisés
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEntrez le nom du développeur pour voir le total de scripts réalisés : ");
        String developerName = scanner.nextLine();
        exoJDBC.totalScriptsByDeveloper(developerName);
        
        // Exécuter une requête libre fournie par l'utilisateur
        exoJDBC.executeUserDefinedQuery();
    }
}